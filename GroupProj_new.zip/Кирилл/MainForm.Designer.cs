﻿
namespace GroupProj.Кирилл {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.radioButton1 = new System.Windows.Forms.RadioButton();
      this.radioButton2 = new System.Windows.Forms.RadioButton();
      this.radioButton3 = new System.Windows.Forms.RadioButton();
      this.radioButton4 = new System.Windows.Forms.RadioButton();
      this.radioButton5 = new System.Windows.Forms.RadioButton();
      this.radioButton6 = new System.Windows.Forms.RadioButton();
      this.radioButton7 = new System.Windows.Forms.RadioButton();
      this.radioButton8 = new System.Windows.Forms.RadioButton();
      this.radioButton9 = new System.Windows.Forms.RadioButton();
      this.radioButton10 = new System.Windows.Forms.RadioButton();
      this.radioButton11 = new System.Windows.Forms.RadioButton();
      this.radioButton12 = new System.Windows.Forms.RadioButton();
      this.radioButton13 = new System.Windows.Forms.RadioButton();
      this.radioButton14 = new System.Windows.Forms.RadioButton();
      this.radioButton15 = new System.Windows.Forms.RadioButton();
      this.radioButton16 = new System.Windows.Forms.RadioButton();
      this.radioButton17 = new System.Windows.Forms.RadioButton();
      this.radioButton18 = new System.Windows.Forms.RadioButton();
      this.rtbOneTime = new System.Windows.Forms.RichTextBox();
      this.rtbSummary = new System.Windows.Forms.RichTextBox();
      this.rtbMonthly = new System.Windows.Forms.RichTextBox();
      this.bttnAddMonthly = new System.Windows.Forms.Button();
      this.bttnOneTime = new System.Windows.Forms.Button();
      this.bttnChangeCurrency = new System.Windows.Forms.Button();
      this.btHistory = new System.Windows.Forms.Button();
      this.bttnAddOneTime = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // radioButton1
      // 
      this.radioButton1.AutoSize = true;
      this.radioButton1.Location = new System.Drawing.Point(18, 16);
      this.radioButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton1.Name = "radioButton1";
      this.radioButton1.Size = new System.Drawing.Size(100, 21);
      this.radioButton1.TabIndex = 0;
      this.radioButton1.TabStop = true;
      this.radioButton1.Text = "Кошелёк 1";
      this.radioButton1.UseVisualStyleBackColor = true;
      this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton2
      // 
      this.radioButton2.AutoSize = true;
      this.radioButton2.Location = new System.Drawing.Point(18, 44);
      this.radioButton2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton2.Name = "radioButton2";
      this.radioButton2.Size = new System.Drawing.Size(100, 21);
      this.radioButton2.TabIndex = 1;
      this.radioButton2.TabStop = true;
      this.radioButton2.Text = "Кошелёк 2";
      this.radioButton2.UseVisualStyleBackColor = true;
      this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton3
      // 
      this.radioButton3.AutoSize = true;
      this.radioButton3.Location = new System.Drawing.Point(18, 73);
      this.radioButton3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton3.Name = "radioButton3";
      this.radioButton3.Size = new System.Drawing.Size(100, 21);
      this.radioButton3.TabIndex = 2;
      this.radioButton3.TabStop = true;
      this.radioButton3.Text = "Кошелёк 3";
      this.radioButton3.UseVisualStyleBackColor = true;
      this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton4
      // 
      this.radioButton4.AutoSize = true;
      this.radioButton4.Location = new System.Drawing.Point(16, 101);
      this.radioButton4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton4.Name = "radioButton4";
      this.radioButton4.Size = new System.Drawing.Size(100, 21);
      this.radioButton4.TabIndex = 3;
      this.radioButton4.TabStop = true;
      this.radioButton4.Text = "Кошелёк 4";
      this.radioButton4.UseVisualStyleBackColor = true;
      this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton5
      // 
      this.radioButton5.AutoSize = true;
      this.radioButton5.Location = new System.Drawing.Point(16, 130);
      this.radioButton5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton5.Name = "radioButton5";
      this.radioButton5.Size = new System.Drawing.Size(100, 21);
      this.radioButton5.TabIndex = 4;
      this.radioButton5.TabStop = true;
      this.radioButton5.Text = "Кошелёк 5";
      this.radioButton5.UseVisualStyleBackColor = true;
      this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton6
      // 
      this.radioButton6.AutoSize = true;
      this.radioButton6.Location = new System.Drawing.Point(18, 158);
      this.radioButton6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton6.Name = "radioButton6";
      this.radioButton6.Size = new System.Drawing.Size(100, 21);
      this.radioButton6.TabIndex = 5;
      this.radioButton6.TabStop = true;
      this.radioButton6.Text = "Кошелёк 6";
      this.radioButton6.UseVisualStyleBackColor = true;
      this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton7
      // 
      this.radioButton7.AutoSize = true;
      this.radioButton7.Location = new System.Drawing.Point(18, 186);
      this.radioButton7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton7.Name = "radioButton7";
      this.radioButton7.Size = new System.Drawing.Size(100, 21);
      this.radioButton7.TabIndex = 6;
      this.radioButton7.TabStop = true;
      this.radioButton7.Text = "Кошелёк 7";
      this.radioButton7.UseVisualStyleBackColor = true;
      this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton8
      // 
      this.radioButton8.AutoSize = true;
      this.radioButton8.Location = new System.Drawing.Point(18, 214);
      this.radioButton8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton8.Name = "radioButton8";
      this.radioButton8.Size = new System.Drawing.Size(100, 21);
      this.radioButton8.TabIndex = 7;
      this.radioButton8.TabStop = true;
      this.radioButton8.Text = "Кошелёк 8";
      this.radioButton8.UseVisualStyleBackColor = true;
      this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton9
      // 
      this.radioButton9.AutoSize = true;
      this.radioButton9.Location = new System.Drawing.Point(16, 242);
      this.radioButton9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton9.Name = "radioButton9";
      this.radioButton9.Size = new System.Drawing.Size(100, 21);
      this.radioButton9.TabIndex = 8;
      this.radioButton9.TabStop = true;
      this.radioButton9.Text = "Кошелёк 9";
      this.radioButton9.UseVisualStyleBackColor = true;
      this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton10
      // 
      this.radioButton10.AutoSize = true;
      this.radioButton10.Location = new System.Drawing.Point(18, 270);
      this.radioButton10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton10.Name = "radioButton10";
      this.radioButton10.Size = new System.Drawing.Size(108, 21);
      this.radioButton10.TabIndex = 9;
      this.radioButton10.TabStop = true;
      this.radioButton10.Text = "Кошелёк 10";
      this.radioButton10.UseVisualStyleBackColor = true;
      this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton11
      // 
      this.radioButton11.AutoSize = true;
      this.radioButton11.Location = new System.Drawing.Point(18, 299);
      this.radioButton11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton11.Name = "radioButton11";
      this.radioButton11.Size = new System.Drawing.Size(108, 21);
      this.radioButton11.TabIndex = 10;
      this.radioButton11.TabStop = true;
      this.radioButton11.Text = "Кошелёк 11";
      this.radioButton11.UseVisualStyleBackColor = true;
      this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton12
      // 
      this.radioButton12.AutoSize = true;
      this.radioButton12.Location = new System.Drawing.Point(18, 327);
      this.radioButton12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton12.Name = "radioButton12";
      this.radioButton12.Size = new System.Drawing.Size(108, 21);
      this.radioButton12.TabIndex = 11;
      this.radioButton12.TabStop = true;
      this.radioButton12.Text = "Кошелёк 12";
      this.radioButton12.UseVisualStyleBackColor = true;
      this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton13
      // 
      this.radioButton13.AutoSize = true;
      this.radioButton13.Location = new System.Drawing.Point(18, 356);
      this.radioButton13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton13.Name = "radioButton13";
      this.radioButton13.Size = new System.Drawing.Size(108, 21);
      this.radioButton13.TabIndex = 12;
      this.radioButton13.TabStop = true;
      this.radioButton13.Text = "Кошелёк 13";
      this.radioButton13.UseVisualStyleBackColor = true;
      this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton14
      // 
      this.radioButton14.AutoSize = true;
      this.radioButton14.Location = new System.Drawing.Point(18, 384);
      this.radioButton14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton14.Name = "radioButton14";
      this.radioButton14.Size = new System.Drawing.Size(108, 21);
      this.radioButton14.TabIndex = 13;
      this.radioButton14.TabStop = true;
      this.radioButton14.Text = "Кошелёк 14";
      this.radioButton14.UseVisualStyleBackColor = true;
      this.radioButton14.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton15
      // 
      this.radioButton15.AutoSize = true;
      this.radioButton15.Location = new System.Drawing.Point(18, 412);
      this.radioButton15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton15.Name = "radioButton15";
      this.radioButton15.Size = new System.Drawing.Size(108, 21);
      this.radioButton15.TabIndex = 14;
      this.radioButton15.TabStop = true;
      this.radioButton15.Text = "Кошелёк 15";
      this.radioButton15.UseVisualStyleBackColor = true;
      this.radioButton15.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton16
      // 
      this.radioButton16.AutoSize = true;
      this.radioButton16.Location = new System.Drawing.Point(18, 441);
      this.radioButton16.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton16.Name = "radioButton16";
      this.radioButton16.Size = new System.Drawing.Size(108, 21);
      this.radioButton16.TabIndex = 15;
      this.radioButton16.TabStop = true;
      this.radioButton16.Text = "Кошелёк 16";
      this.radioButton16.UseVisualStyleBackColor = true;
      this.radioButton16.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton17
      // 
      this.radioButton17.AutoSize = true;
      this.radioButton17.Location = new System.Drawing.Point(18, 469);
      this.radioButton17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton17.Name = "radioButton17";
      this.radioButton17.Size = new System.Drawing.Size(108, 21);
      this.radioButton17.TabIndex = 16;
      this.radioButton17.TabStop = true;
      this.radioButton17.Text = "Кошелёк 17";
      this.radioButton17.UseVisualStyleBackColor = true;
      this.radioButton17.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // radioButton18
      // 
      this.radioButton18.AutoSize = true;
      this.radioButton18.Location = new System.Drawing.Point(18, 498);
      this.radioButton18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.radioButton18.Name = "radioButton18";
      this.radioButton18.Size = new System.Drawing.Size(108, 21);
      this.radioButton18.TabIndex = 17;
      this.radioButton18.TabStop = true;
      this.radioButton18.Text = "Кошелёк 18";
      this.radioButton18.UseVisualStyleBackColor = true;
      this.radioButton18.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
      // 
      // rtbOneTime
      // 
      this.rtbOneTime.Location = new System.Drawing.Point(674, 14);
      this.rtbOneTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.rtbOneTime.Name = "rtbOneTime";
      this.rtbOneTime.ReadOnly = true;
      this.rtbOneTime.Size = new System.Drawing.Size(376, 333);
      this.rtbOneTime.TabIndex = 20;
      this.rtbOneTime.Text = "";
      // 
      // rtbSummary
      // 
      this.rtbSummary.Location = new System.Drawing.Point(132, 16);
      this.rtbSummary.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.rtbSummary.Name = "rtbSummary";
      this.rtbSummary.ReadOnly = true;
      this.rtbSummary.Size = new System.Drawing.Size(532, 134);
      this.rtbSummary.TabIndex = 21;
      this.rtbSummary.Text = "";
      // 
      // rtbMonthly
      // 
      this.rtbMonthly.Location = new System.Drawing.Point(132, 158);
      this.rtbMonthly.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.rtbMonthly.Name = "rtbMonthly";
      this.rtbMonthly.ReadOnly = true;
      this.rtbMonthly.Size = new System.Drawing.Size(532, 358);
      this.rtbMonthly.TabIndex = 22;
      this.rtbMonthly.Text = "";
      this.rtbMonthly.TextChanged += new System.EventHandler(this.rtbMonthly_TextChanged);
      // 
      // bttnAddMonthly
      // 
      this.bttnAddMonthly.Location = new System.Drawing.Point(675, 357);
      this.bttnAddMonthly.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.bttnAddMonthly.Name = "bttnAddMonthly";
      this.bttnAddMonthly.Size = new System.Drawing.Size(89, 105);
      this.bttnAddMonthly.TabIndex = 23;
      this.bttnAddMonthly.Text = "Добавить ежемес. доход/расход";
      this.bttnAddMonthly.UseVisualStyleBackColor = true;
      this.bttnAddMonthly.Click += new System.EventHandler(this.bttnAddMonthly_Click);
      // 
      // bttnOneTime
      // 
      this.bttnOneTime.Location = new System.Drawing.Point(871, 357);
      this.bttnOneTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.bttnOneTime.Name = "bttnOneTime";
      this.bttnOneTime.Size = new System.Drawing.Size(185, 105);
      this.bttnOneTime.TabIndex = 24;
      this.bttnOneTime.Text = "Добавить разовый доход/расход";
      this.bttnOneTime.UseVisualStyleBackColor = true;
      this.bttnOneTime.Click += new System.EventHandler(this.bttnAddOneTime_Click);
      // 
      // bttnChangeCurrency
      // 
      this.bttnChangeCurrency.Location = new System.Drawing.Point(675, 469);
      this.bttnChangeCurrency.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.bttnChangeCurrency.Name = "bttnChangeCurrency";
      this.bttnChangeCurrency.Size = new System.Drawing.Size(173, 50);
      this.bttnChangeCurrency.TabIndex = 25;
      this.bttnChangeCurrency.Text = "Сменить валюту";
      this.bttnChangeCurrency.UseVisualStyleBackColor = true;
      this.bttnChangeCurrency.Click += new System.EventHandler(this.bttnChangeCurrency_Click);
      // 
      // btHistory
      // 
      this.btHistory.Location = new System.Drawing.Point(883, 469);
      this.btHistory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btHistory.Name = "btHistory";
      this.btHistory.Size = new System.Drawing.Size(173, 50);
      this.btHistory.TabIndex = 26;
      this.btHistory.Text = "История доходов/расходов за период";
      this.btHistory.UseVisualStyleBackColor = true;
      this.btHistory.Click += new System.EventHandler(this.btHistory_Click);
      // 
      // bttnAddOneTime
      // 
      this.bttnAddOneTime.Location = new System.Drawing.Point(772, 356);
      this.bttnAddOneTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.bttnAddOneTime.Name = "bttnAddOneTime";
      this.bttnAddOneTime.Size = new System.Drawing.Size(91, 106);
      this.bttnAddOneTime.TabIndex = 27;
      this.bttnAddOneTime.Text = "Удалить ежемес. доход/расход";
      this.bttnAddOneTime.UseVisualStyleBackColor = true;
      this.bttnAddOneTime.Click += new System.EventHandler(this.bttnAddOneTime_Click_1);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1067, 538);
      this.Controls.Add(this.bttnAddOneTime);
      this.Controls.Add(this.btHistory);
      this.Controls.Add(this.bttnChangeCurrency);
      this.Controls.Add(this.bttnOneTime);
      this.Controls.Add(this.bttnAddMonthly);
      this.Controls.Add(this.rtbMonthly);
      this.Controls.Add(this.rtbSummary);
      this.Controls.Add(this.rtbOneTime);
      this.Controls.Add(this.radioButton18);
      this.Controls.Add(this.radioButton17);
      this.Controls.Add(this.radioButton16);
      this.Controls.Add(this.radioButton15);
      this.Controls.Add(this.radioButton14);
      this.Controls.Add(this.radioButton13);
      this.Controls.Add(this.radioButton12);
      this.Controls.Add(this.radioButton11);
      this.Controls.Add(this.radioButton10);
      this.Controls.Add(this.radioButton9);
      this.Controls.Add(this.radioButton8);
      this.Controls.Add(this.radioButton7);
      this.Controls.Add(this.radioButton6);
      this.Controls.Add(this.radioButton5);
      this.Controls.Add(this.radioButton4);
      this.Controls.Add(this.radioButton3);
      this.Controls.Add(this.radioButton2);
      this.Controls.Add(this.radioButton1);
      this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.Name = "MainForm";
      this.Text = "Form1";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.RadioButton radioButton1;
    private System.Windows.Forms.RadioButton radioButton2;
    private System.Windows.Forms.RadioButton radioButton3;
    private System.Windows.Forms.RadioButton radioButton4;
    private System.Windows.Forms.RadioButton radioButton5;
    private System.Windows.Forms.RadioButton radioButton6;
    private System.Windows.Forms.RadioButton radioButton7;
    private System.Windows.Forms.RadioButton radioButton8;
    private System.Windows.Forms.RadioButton radioButton9;
    private System.Windows.Forms.RadioButton radioButton10;
    private System.Windows.Forms.RadioButton radioButton11;
    private System.Windows.Forms.RadioButton radioButton12;
    private System.Windows.Forms.RadioButton radioButton13;
    private System.Windows.Forms.RadioButton radioButton14;
    private System.Windows.Forms.RadioButton radioButton15;
    private System.Windows.Forms.RadioButton radioButton16;
    private System.Windows.Forms.RadioButton radioButton17;
    private System.Windows.Forms.RadioButton radioButton18;
    private System.Windows.Forms.RichTextBox rtbOneTime;
    private System.Windows.Forms.RichTextBox rtbSummary;
    private System.Windows.Forms.RichTextBox rtbMonthly;
    private System.Windows.Forms.Button bttnAddMonthly;
    private System.Windows.Forms.Button bttnOneTime;
    private System.Windows.Forms.Button bttnChangeCurrency;
    private System.Windows.Forms.Button btHistory;
    private System.Windows.Forms.Button bttnAddOneTime;
  }
}

