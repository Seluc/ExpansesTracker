﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProj {
  public static class Constants {
    public static readonly string ConStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Seluc\Source\Repos\GroupProj_new\DataBase\DB.mdf;Integrated Security=True";
    public static readonly int AccountsCnt = 18;
  }
}
